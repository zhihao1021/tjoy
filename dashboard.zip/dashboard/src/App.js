import React, { useState } from 'react';
import Header from './components/Header';
import LeftPanel from './components/LeftPanel';
import CenterPanel from './components/CenterPanel';
import RightPanel from './components/RightPanel';
import './App.scss';

function App() {
  const [timePeriod, setTimePeriod] = useState('前一個月');

  return (
    <div className="app">
      <Header />
      <div className="dashboard-content">
        <LeftPanel />
        <CenterPanel />
        <RightPanel 
          timePeriod={timePeriod} 
          setTimePeriod={setTimePeriod}
        />
      </div>
    </div>
  );
}

export default App;
